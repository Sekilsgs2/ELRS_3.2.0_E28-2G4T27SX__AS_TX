UID = '-DMY_BINDING_PHRASE="12345678"'
bindingPhraseHash = hashlib.md5(UID.encode()).digest()
UIDbytes = ",".join(list(map(str, bindingPhraseHash))[0:6])
print('MY_UID="'+UIDbytes+'"')
