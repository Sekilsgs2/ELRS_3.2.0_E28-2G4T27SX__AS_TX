The SCTM, PWM, GPTM, and MCTM timer have similar architecture. They use the same driver,
"ht32fxxxxx_tm.c/.h" to save the code size. For those timers, please refet to the TM driver/example.