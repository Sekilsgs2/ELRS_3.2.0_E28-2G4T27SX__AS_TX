/*********************************************************************************************************//**
 * @file    ht32f5xxxx_usart.c
 * @version $Rev:: 7054         $
 * @date    $Date:: 2023-07-24 #$
 * @brief   This file provides all the USART firmware functions.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32f5xxxx_usart.h"
#include <stddef.h>

/** @addtogroup HT32F5xxxx_Peripheral_Driver HT32F5xxxx Peripheral Driver
  * @{
  */

/** @defgroup USART USART
  * @brief USART driver modules
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
/** @defgroup USART_Private_Define USART private definitions
  * @{
  */
#define CR_CLEAR_Mask             ((u32)0xFFFFE0FC)

#define USART_BREAK_ON            ((u32)0x00004000)
#define USART_BREAK_OFF           ((u32)0xFFFFBFFF)

#define USART_PBE_ON              ((u32)0x00000800)
#define USART_SPE_ON              ((u32)0x00002000)
#define USART_SPE_OFF             ((u32)0xFFFFDFFF)

#define USART_EN_ON               ((u32)0x00000010)

#define USART_HFCEN_ON            ((u32)0x00000008)
#define USART_HFCEN_OFF           ((u32)0xFFFFFFF7)

#define USART_RXTOEN_ON           ((u32)0x00000080)

#define FCR_TL_Mask               ((u32)0x00000030)

#define TRSM_CLEAR_Mask           ((u32)0xFFFFFFFB)
#define TPR_TG_Mask               ((u32)0xFFFF00FF)
#define ICR_IRDAPSC_Mask          ((u32)0xFFFF00FF)
#define TPR_RXTOIC_Mask           ((u32)0xFFFFFF80)
#define RS485CR_ADDM_Mask         ((u32)0xFFFF00FF)

#define USART_IRDA_ON             ((u32)0x00000001)
#define USART_IRDA_OFF            ((u32)0xFFFFFFFE)

#define USART_INV_ON              ((u32)0x00000010)

#define USART_RS485NMM_ON         ((u32)0x00000002)
#define USART_RS485NMM_OFF        ((u32)0xFFFFFFFD)

#define USART_RS485AAD_ON         ((u32)0x00000004)
#define USART_RS485AAD_OFF        ((u32)0xFFFFFFFB)
/**
  * @}
  */

/* Global functions ----------------------------------------------------------------------------------------*/
/** @defgroup USART_Exported_Functions USART exported functions
  * @{
  */
/*********************************************************************************************************//**
 * @brief Deinitialize the USART/UART peripheral registers to their default reset values.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @retval None
 ************************************************************************************************************/
void USART_DeInit(HT_USART_TypeDef* USARTx)
{
  RSTCU_PeripReset_TypeDef RSTCUReset = {{0}};
  u32 uIPAddr = (u32)USARTx;

  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));

  switch (uIPAddr)
  {
    #if (!LIBCFG_NO_USART0)
    case HT_USART0_BASE:
    {
      RSTCUReset.Bit.USART0 = 1;
      break;
    }
    #endif
    #if (LIBCFG_USART1)
    case HT_USART1_BASE:
    {
      RSTCUReset.Bit.USART1 = 1;
      break;
    }
    #endif
    case HT_UART0_BASE:
    {
      RSTCUReset.Bit.UART0 = 1;
      break;
    }
    #if (LIBCFG_UART1)
    case HT_UART1_BASE:
    {
      RSTCUReset.Bit.UART1 = 1;
      break;
    }
    #endif
    #if (LIBCFG_UART2)
    case HT_UART2_BASE:
    {
      RSTCUReset.Bit.UART2 = 1;
      break;
    }
    #endif
    #if (LIBCFG_UART3)
    case HT_UART3_BASE:
    {
      RSTCUReset.Bit.UART3 = 1;
      break;
    }
    #endif
  }

  RSTCU_PeripReset(RSTCUReset, ENABLE);
}

/*********************************************************************************************************//**
 * @brief Initialize the USART/UART peripheral according to the specified parameters in the USART_InitStruct.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_InitStruct: pointer to a USART_InitTypeDef structure.
 * @retval None
 ************************************************************************************************************/
void USART_Init(HT_USART_TypeDef* USARTx, USART_InitTypeDef* USART_InitStruct)
{
  u32 uIPClock = 0;
  u32 uIPAddr = (u32)USARTx;

  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_BAUDRATE(USART_InitStruct->USART_BaudRate));
  Assert_Param(IS_USART_WORD_LENGTH(USART_InitStruct->USART_WordLength));
  Assert_Param(IS_USART_STOPBITS(USART_InitStruct->USART_StopBits));
  Assert_Param(IS_USART_PARITY(USART_InitStruct->USART_Parity));
  Assert_Param(IS_USART_MODE(USART_InitStruct->USART_Mode));

  USARTx->CR = (USARTx->CR & CR_CLEAR_Mask) | USART_InitStruct->USART_StopBits |
                USART_InitStruct->USART_WordLength | USART_InitStruct->USART_Parity |
                USART_InitStruct->USART_Mode;

  switch (uIPAddr)
  {
    #if (!LIBCFG_NO_USART0)
    case HT_USART0_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_USART0);
      break;
    }
    #endif
    #if (LIBCFG_USART1)
    case HT_USART1_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_USART1);
      break;
    }
    #endif
    case HT_UART0_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_UART0);
      break;
    }
    #if (LIBCFG_UART1)
    case HT_UART1_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_UART1);
      break;
    }
    #endif
    #if (LIBCFG_UART2)
    case HT_UART2_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_UART2);
      break;
    }
    #endif
    #if (LIBCFG_UART3)
    case HT_UART3_BASE:
    {
      uIPClock = CKCU_GetPeripFrequency(CKCU_PCLK_UART3);
      break;
    }
    #endif
  }

  USARTx->DLR = uIPClock / (u32)USART_InitStruct->USART_BaudRate;
}

/*********************************************************************************************************//**
 * @brief Fill each USART_InitStruct member with its default value.
 * @param USART_InitStruct: pointer to a USART_InitTypeDef structure.
 * @retval None
 ************************************************************************************************************/
void USART_StructInit(USART_InitTypeDef* USART_InitStruct)
{
  /* USART_InitStruct members default value                                                                 */
  USART_InitStruct->USART_BaudRate = 9600;
  USART_InitStruct->USART_WordLength = USART_WORDLENGTH_8B;
  USART_InitStruct->USART_StopBits = USART_STOPBITS_1;
  USART_InitStruct->USART_Parity = USART_PARITY_NO;
  USART_InitStruct->USART_Mode = USART_MODE_NORMAL;
}

/*********************************************************************************************************//**
 * @brief USART/UART send data to Tx.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param Data: the data to be transmitted.
 * @retval None
 ************************************************************************************************************/
void USART_SendData(HT_USART_TypeDef* USARTx, u16 Data)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_DATA(Data));

  USARTx->DR = Data;
}

/*********************************************************************************************************//**
 * @brief USART/UART receive data from Rx.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @retval The received data.
 ************************************************************************************************************/
u16 USART_ReceiveData(HT_USART_TypeDef* USARTx)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));

  return (u16)(USARTx->DR);
}

/*********************************************************************************************************//**
 * @brief Get the specified USART/UART status flags.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_FLAG_x: Specify the flag to be check.
 *   This parameter can be one of the following values:
 *     @arg USART_FLAG_RXDNE :
 *     @arg USART_FLAG_OE    :
 *     @arg USART_FLAG_PE    :
 *     @arg USART_FLAG_FE    :
 *     @arg USART_FLAG_BI    :
 *     @arg USART_FLAG_RXDR  :
 *     @arg USART_FLAG_TOUT  :
 *     @arg USART_FLAG_TXDE  :
 *     @arg USART_FLAG_TXC   :
 *     @arg USART_FLAG_RSADD :
 *     @arg USART_FLAG_CTSC  :
 *     @arg USART_FLAG_CTSS  :
 *     @arg USART_FLAG_LBD   :
 * @retval SET or RESET
 ************************************************************************************************************/
FlagStatus USART_GetFlagStatus(HT_USART_TypeDef* USARTx, u32 USART_FLAG_x)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_FLAG(USART_FLAG_x));

  if ((USARTx->SR & USART_FLAG_x) != (u32)RESET)
  {
    return (SET);
  }
  else
  {
    return (RESET);
  }
}

/*********************************************************************************************************//**
 * @brief Get the specified USART/UART INT status.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_INT_x: Specify if the USART/UART interrupt source.
 *   This parameter can be one of the following values:
 *     @arg USART_INT_RXDR  :
 *     @arg USART_INT_TXDE  :
 *     @arg USART_INT_TXC   :
 *     @arg USART_INT_OE    :
 *     @arg USART_INT_PE    :
 *     @arg USART_INT_FE    :
 *     @arg USART_INT_BI    :
 *     @arg USART_INT_RSADD :
 *     @arg USART_INT_TOUT  :
 *     @arg USART_INT_CTS   :
 *     @arg USART_INT_LBD   :
 * @retval SET or RESET
 ************************************************************************************************************/
FlagStatus USART_GetIntStatus(HT_USART_TypeDef* USARTx, u32 USART_INT_x)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_INT(USART_INT_x));

  if ((USARTx->IER & USART_INT_x) != (u32)RESET)
  {
    return (SET);
  }
  else
  {
    return (RESET);
  }
}

/*********************************************************************************************************//**
 * @brief Clear the specified USART/UART flags.
 * @param USARTx: where USARTx is the selected USART/UART from the USART/UART peripherals.
 * @param USART_Flag: Specify the flag to check.
 *   This parameter can be any combination of the following values:
 *     @arg USART_FLAG_OE    :
 *     @arg USART_FLAG_PE    :
 *     @arg USART_FLAG_FE    :
 *     @arg USART_FLAG_BI    :
 *     @arg USART_FLAG_TOUT  :
 *     @arg USART_FLAG_RSADD :
 *     @arg USART_FLAG_CTSC  :
 *     @arg USART_FLAG_LBD   :
 * @retval SET or RESET
 ************************************************************************************************************/
void USART_ClearFlag(HT_USART_TypeDef* USARTx, u32 USART_Flag)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_CLEAR_FLAG(USART_Flag));

  USARTx->SR &= USART_Flag;
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART/UART interrupts.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_INT_x: Specify if the USART/UART interrupt source to be enabled or disabled.
 *   This parameter can be one of the following values:
 *     @arg USART_INT_RXDR  :
 *     @arg USART_INT_TXDE  :
 *     @arg USART_INT_TXC   :
 *     @arg USART_INT_OE    :
 *     @arg USART_INT_PE    :
 *     @arg USART_INT_FE    :
 *     @arg USART_INT_BI    :
 *     @arg USART_INT_RSADD :
 *     @arg USART_INT_TOUT  :
 *     @arg USART_INT_CTS   :
*      @arg USART_INT_LBD   :
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_IntConfig(HT_USART_TypeDef* USARTx, u32 USART_INT_x, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_INT(USART_INT_x));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->IER |= USART_INT_x;
  }
  else
  {
    USARTx->IER &= ~USART_INT_x;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART Tx/Rx.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param TxRx: This parameter can be USART_CMD_TX or USART_CMD_RX.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_TxRxCmd(HT_USART_TypeDef* USARTx, u32 TxRx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));
  if (NewState != DISABLE)
  {
    USARTx->CR |= (USART_EN_ON << TxRx);
  }
  else
  {
    USARTx->CR &= ~(USART_EN_ON << TxRx);
  }
}

#if (LIBCFG_PDMA)
/*********************************************************************************************************//**
 * @brief Enable or Disable the USART/UART PDMA interface.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_PDMAREQ: specify the USART/UART PDMA transfer request to be enabled or disabled.
 *   This parameter can be any combination of the following values:
 *     @arg USART_PDMAREQ_TX
 *     @arg USART_PDMAREQ_RX
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_PDMACmd(HT_USART_TypeDef* USARTx, u32 USART_PDMAREQ, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_PDMA_REQ(USART_PDMAREQ));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->CR |= USART_PDMAREQ;
  }
  else
  {
    USARTx->CR &= ~USART_PDMAREQ;
  }
}
#endif

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART/UART break control function.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_ForceBreakCmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->CR |= USART_BREAK_ON;
  }
  else
  {
    USARTx->CR &= USART_BREAK_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART/UART stick parity function.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_StickParityCmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->CR |= USART_SPE_ON | USART_PBE_ON;
  }
  else
  {
    USARTx->CR &= USART_SPE_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Configure the stick parity value of the USART/UART.
 * @param USARTx: Parameter to select the UxART peripheral.
 * @param USART_StickParity: Specify the stick parity of the USART/UART.
 *   This parameter can be one of the following values:
 *     @arg USART_STICK_LOW
 *     @arg USART_STICK_HIGH
 * @retval None
 ************************************************************************************************************/
void USART_StickParityConfig(HT_USART_TypeDef * USARTx, u32 USART_StickParity)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_STICK_PARITY(USART_StickParity));

  if (USART_StickParity != USART_STICK_HIGH)
  {
    USARTx->CR |= USART_STICK_LOW;
  }
  else
  {
    USARTx->CR &= USART_STICK_HIGH;
  }
}

/*********************************************************************************************************//**
 * @brief Set the specified USART guard time.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_GuardTime: Specify the guard time.
 * @retval None
 ************************************************************************************************************/
void USART_SetGuardTime(HT_USART_TypeDef* USARTx, u32 USART_GuardTime)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_GUARD_TIME(USART_GuardTime));

  USARTx->TPR = (USARTx->TPR & TPR_TG_Mask) | (USART_GuardTime << 0x08);
}

/*********************************************************************************************************//**
 * @brief Configure the Tx/Rx FIFO Interrupt Trigger Level.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param TxRx: This parameter can be USART_CMD_TX or USART_CMD_RX.
 * @param USART_tl: Specify the USART Tx/Rx FIFO interrupt trigger level.
 *   This parameter can be one of the following values:
 *     @arg USART_RXTL_01
 *     @arg USART_RXTL_02
 *     @arg USART_RXTL_04
 *     @arg USART_RXTL_06
 *     @arg USART_TXTL_00
 *     @arg USART_TXTL_02
 *     @arg USART_TXTL_04
 *     @arg USART_TXTL_06
 * @retval None
 ************************************************************************************************************/
void USART_TXRXTLConfig(HT_USART_TypeDef* USARTx, u32 TxRx, u32 USART_tl)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_TL(USART_tl));

  USARTx->FCR = (USARTx->FCR & ~(FCR_TL_Mask << (TxRx * 2))) | (USART_tl << (TxRx * 2));
}

/*********************************************************************************************************//**
 * @brief Set the USART FIFO time-out value.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_TimeOut: Specify the time-out value.
 * @retval None
 ************************************************************************************************************/
void USART_SetTimeOutValue(HT_USART_TypeDef* USARTx, u32 USART_TimeOut)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_TIMEOUT(USART_TimeOut));

  USARTx->TPR = (USARTx->TPR & TPR_RXTOIC_Mask) | USART_TimeOut | USART_RXTOEN_ON;
}

/*********************************************************************************************************//**
 * @brief Clear both the write and read point in USART Tx FIFO or Rx FIFO.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_FIFODirection: Determine TX FIFO or Rx FIFO that is to be reset.
 *   This parameter can be any combination of the following values:
 *     @arg USART_FIFO_TX
 *     @arg USART_FIFO_RX
 * @retval None
 ************************************************************************************************************/
void USART_FIFOReset(HT_USART_TypeDef* USARTx, u32 USART_FIFODirection)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_FIFO_DIRECTION(USART_FIFODirection));

  USARTx->FCR |= USART_FIFODirection;
}

/*********************************************************************************************************//**
 * @brief Return the status of specified USART FIFO.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_FIFODirection: specify the FIFO that is to be check.
 *   This parameter can be one of the following values:
 *     @arg USART_FIFO_TX
 *     @arg USART_FIFO_RX
 * @retval The number of data in Tx FIFO or Rx FIFO.
 ************************************************************************************************************/
u8 USART_GetFIFOStatus(HT_USART_TypeDef* USARTx, u32 USART_FIFODirection)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_FIFO_DIRECTION(USART_FIFODirection));

  if (USART_FIFODirection == USART_FIFO_TX)
  {
    return (u8)((USARTx->FCR & 0xF0000) >> 16);
  }
  else
  {
    return (u8)((USARTx->FCR & 0xF000000) >> 24);
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART hardware flow control.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_HardwareFlowControlCmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->CR |= USART_HFCEN_ON;
  }
  else
  {
    USARTx->CR &= USART_HFCEN_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART IrDA interface.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_IrDACmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->ICR |= USART_IRDA_ON;
  }
  else
  {
    USARTx->ICR &= USART_IRDA_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Configure the USART IrDA interface.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_IrDAMode: Specify the USART IrDA mode.
 *   This parameter can be one of the following values:
 *     @arg USART_IRDA_LOWPOWER
 *     @arg USART_IRDA_NORMAL
 * @retval None
 ************************************************************************************************************/
void USART_IrDAConfig(HT_USART_TypeDef* USARTx, u32 USART_IrDAMode)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_IRDA_MODE(USART_IrDAMode));

  if (USART_IrDAMode != USART_IRDA_NORMAL)
  {
    USARTx->ICR |= USART_IRDA_LOWPOWER;
  }
  else
  {
    USARTx->ICR &= USART_IRDA_NORMAL;
  }
}

/*********************************************************************************************************//**
 * @brief Set the specified USART IrDA prescaler.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_IrDAPrescaler: Specify the USART IrDA prescaler.
 * @retval None
 ************************************************************************************************************/
void USART_SetIrDAPrescaler(HT_USART_TypeDef* USARTx, u32 USART_IrDAPrescaler)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_IRDA_PRESCALER(USART_IrDAPrescaler));

  USARTx->ICR = (USARTx->ICR & ICR_IRDAPSC_Mask) | (USART_IrDAPrescaler << 0x08);
}

/*********************************************************************************************************//**
 * @brief Enable the IrDA transmitter or receiver.
 * @param USARTx: Parameter to select the USART peripheral, x can be 0 or 1.
 * @param USART_IrDADirection: Specify the USART IrDA direction select.
 *   This parameter can be one of the following values:
 *     @arg USART_IRDA_TX
 *     @arg USART_IRDA_RX
 * @retval None
 ************************************************************************************************************/
void USART_IrDADirectionConfig(HT_USART_TypeDef* USARTx, u32 USART_IrDADirection)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_IRDA_DIRECTION(USART_IrDADirection));

  if (USART_IrDADirection != USART_IRDA_RX)
  {
    USARTx->ICR |= USART_IRDA_TX;
  }
  else
  {
    USARTx->ICR &= USART_IRDA_RX;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable inverting serial output/input function of IrDA on the specified USART.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param inout: This parameter can be USART_CMD_OUT or USART_CMD_IN.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_IrDAInvtCmd(HT_USART_TypeDef* USARTx, u32 inout, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->ICR |= (USART_INV_ON << inout);
  }
  else
  {
    USARTx->ICR &= ~(USART_INV_ON << inout);
  }
}

/*********************************************************************************************************//**
 * @brief Configure the polarity of USART RS485 transmitter enable signal.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_RS485Polarity: Specify the polarity of USART RS485 Tx enable signal.
 *   This parameter can be one of the following values:
 *     @arg USART_RS485POL_LOW
 *     @arg USART_RS485POL_HIGH
 * @retval None
 ************************************************************************************************************/
void USART_RS485TxEnablePolarityConfig(HT_USART_TypeDef* USARTx, u32 USART_RS485Polarity)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_RS485_POLARITY(USART_RS485Polarity));

  if (USART_RS485Polarity != USART_RS485POLARITY_HIGH)
  {
    USARTx->RCR |= USART_RS485POLARITY_LOW;
  }
  else
  {
    USARTx->RCR &= USART_RS485POLARITY_HIGH;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART RS485 normal multi-drop operation mode.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_RS485NMMCmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->RCR |= USART_RS485NMM_ON;
  }
  else
  {
    USARTx->RCR &= USART_RS485NMM_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Enable or Disable the USART RS485 normal multi-drop operation mode.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param NewState: This parameter can be ENABLE or DISABLE.
 * @retval None
 ************************************************************************************************************/
void USART_RS485AADCmd(HT_USART_TypeDef* USARTx, ControlStatus NewState)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_CONTROL_STATUS(NewState));

  if (NewState != DISABLE)
  {
    USARTx->RCR |= USART_RS485AAD_ON;
  }
  else
  {
    USARTx->RCR &= USART_RS485AAD_OFF;
  }
}

/*********************************************************************************************************//**
 * @brief Set the specified USART RS485 address match value.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_AddressMatchValue: specify the USART RS485 address match value.
 * @retval None
 ************************************************************************************************************/
void USART_SetAddressMatchValue(HT_USART_TypeDef* USARTx, u32 USART_AddressMatchValue)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_ADDRESS_MATCH_VALUE(USART_AddressMatchValue));

  USARTx->RCR = (USARTx->RCR & RS485CR_ADDM_Mask) | (u32)(USART_AddressMatchValue << 0x08);
}

/*********************************************************************************************************//**
 * @brief Initialize the clock of the USART peripheral according to the specified parameters
 *        in the USART_ClockInitStruct.
 * @param USARTx: Parameter to select the USART peripheral.
 * @param USART_SynClock_InitStruct: pointer to a USART_SynClock_InitTypeDef structure.
 * @retval None
 ************************************************************************************************************/
void USART_SynClockInit(HT_USART_TypeDef* USARTx, USART_SynClock_InitTypeDef* USART_SynClock_InitStruct)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_SYNCHRONOUS_CLOCK(USART_SynClock_InitStruct->USART_ClockEnable));
  Assert_Param(IS_USART_SYNCHRONOUS_PHASE(USART_SynClock_InitStruct->USART_ClockPhase));
  Assert_Param(IS_USART_SYNCHRONOUS_POLARITY(USART_SynClock_InitStruct->USART_ClockPolarity));
  Assert_Param(IS_USART_TRANSFER_MODE(USART_SynClock_InitStruct->USART_TransferSelectMode));

  USARTx->SCR = USART_SynClock_InitStruct->USART_ClockEnable | USART_SynClock_InitStruct->USART_ClockPhase |
                USART_SynClock_InitStruct->USART_ClockPolarity;

  USARTx->CR = (USARTx->CR & TRSM_CLEAR_Mask) | USART_SynClock_InitStruct->USART_TransferSelectMode;
}

/*********************************************************************************************************//**
 * @brief Fill each USART_SynClockInitStruct member with its default value.
 * @param USART_SynClock_InitStruct: pointer to a USART_SynClock_InitTypeDef structure.
 * @retval None
 ************************************************************************************************************/
void USART_SynClockStructInit(USART_SynClock_InitTypeDef* USART_SynClock_InitStruct)
{
  /* USART_ClockInitStruct members default value                                                            */
  USART_SynClock_InitStruct->USART_ClockEnable =  USART_SYN_CLOCK_DISABLE;
  USART_SynClock_InitStruct->USART_ClockPhase = USART_SYN_CLOCK_PHASE_FIRST;
  USART_SynClock_InitStruct->USART_ClockPolarity = USART_SYN_CLOCK_POLARITY_LOW;
  USART_SynClock_InitStruct->USART_TransferSelectMode = USART_LSB_FIRST;
}

static UART_HandleTypeDef *uart_handlers[2] = {NULL};

/* Aim of the function is to get serial_s pointer using huart pointer */
/* Highly inspired from magical linux kernel's "container_of" */
serial_t *get_serial_obj(UART_HandleTypeDef *huart)
{
  struct serial_s *obj_s;
  serial_t *obj;

  obj_s = (struct serial_s *)((char *)huart - offsetof(struct serial_s, handle));
  obj = (serial_t *)((char *)obj_s - offsetof(serial_t, uart));

  return (obj);
}

void HAL_NVIC_SetPriority(IRQn_Type IRQn, uint32_t PreemptPriority, uint32_t SubPriority)
{
}

void HAL_UART_Init(UART_HandleTypeDef *huart)
{
  /* Check the UART handle allocation */
  if (huart == NULL)
  {
    return;
  }

  if (huart->gState == HAL_UART_STATE_RESET)
  {
    /* Allocate lock resource and initialize it */
    huart->Lock = HAL_UNLOCKED;

  }
  
  /* Initialize the UART ErrorCode */
  huart->ErrorCode = HAL_UART_ERROR_NONE;

  /* Initialize the UART State */
  huart->gState = HAL_UART_STATE_READY;
  huart->RxState = HAL_UART_STATE_READY;
  
  __HAL_UNLOCK(huart);

  return;
}

void uart_init_stm32(serial_t *obj, uint32_t baudrate, uint32_t databits, uint32_t parity, uint32_t stopbits)
{
  if (obj == NULL) {
    return;
  }

  UART_HandleTypeDef *huart = &(obj->handle);

  obj->uart = HT_USART0;
  
  obj->pae = 0;
  obj->fre = 0;
  obj->ove = 0;



 {
		// Config AFIO mode as Rx and Tx function.
		AFIO_GPxConfig(GPIO_PB, AFIO_PIN_0, AFIO_FUN_USART_UART);
		AFIO_GPxConfig(GPIO_PB, AFIO_PIN_1, AFIO_FUN_USART_UART);
		
    uart_handlers[obj->index] = huart;
		
		USART_StructInit( &huart->Init);
		huart->Instance          = (HT_USART_TypeDef *)(obj->uart);
		huart->Init.USART_BaudRate = baudrate;
		huart->Init.USART_WordLength = USART_WORDLENGTH_8B;
		huart->Init.USART_StopBits = USART_STOPBITS_1;
		huart->Init.USART_Parity = USART_PARITY_NO;
		huart->Init.USART_Mode = USART_MODE_NORMAL;
		USART_Init(huart->Instance  , &huart->Init);
		// Seting UART0 interrupt-flag
		//USART_IntConfig(HT_USART0, USART_INT_RXDR, ENABLE);
		// Enable UART0
	  HAL_UART_Init(huart);
		USART_TxCmd(huart->Instance, ENABLE);
		USART_RxCmd(huart->Instance, ENABLE);
		NVIC_SetPriority(USART0_IRQn, 5);
		
		// Configure USART0 interrupt
		//NVIC_EnableIRQ(USART0_IRQn);
    obj->index = 0;
    obj->irq = USART0_IRQn;
  }
}

static void UART_RxISR_8BIT(UART_HandleTypeDef *huart)
{
  uint16_t uhMask = 0xFF;
  uint16_t  uhdata;
  serial_t *obj = get_serial_obj(huart);

  /* Check that a Rx process is ongoing */
  if (huart->RxState == HAL_UART_STATE_BUSY_RX)
  {
    uhdata = (uint16_t) READ_REG(obj->uart->DR);
    *huart->pRxBuffPtr = (uint8_t)(uhdata & (uint8_t)uhMask);
    huart->pRxBuffPtr++;
    huart->RxXferCount--;

    if (huart->RxXferCount == 0U)
    {
      /* Disable the UART Parity Error Interrupt and RXNE interrupts */
      ATOMIC_CLEAR_BIT(obj->uart->IER, (USART_INT_RXDR | USART_INT_OE | USART_INT_PE | USART_INT_FE));

      /* Rx process is completed, restore huart->RxState to Ready */
      huart->RxState = HAL_UART_STATE_READY;

      /* Clear RxISR function pointer */
      huart->RxISR = NULL;


      /*Call legacy weak Rx complete callback*/
	  if (obj) {
		obj->rx_callback(obj);
	  }

    }
  }
  else
  {
    /* Clear RXNE interrupt flag */
    //__HAL_UART_SEND_REQ(huart, UART_RXDATA_FLUSH_REQUEST);
  }
}


/**
  * @brief  Start Receive operation in interrupt mode.
  * @note   This function could be called by all HAL UART API providing reception in Interrupt mode.
  * @note   When calling this function, parameters validity is considered as already checked,
  *         i.e. Rx State, buffer address, ...
  *         UART Handle is assumed as Locked.
  * @param  huart UART handle.
  * @param  pData Pointer to data buffer (u8 or u16 data elements).
  * @param  Size  Amount of data elements (u8 or u16) to be received.
  * @retval HAL status
  */
HAL_StatusTypeDef UART_Start_Receive_IT(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size)
{
  huart->pRxBuffPtr  = pData;
  huart->RxXferSize  = Size;
  huart->RxXferCount = Size;
  huart->RxISR       = NULL;

  huart->ErrorCode = HAL_UART_ERROR_NONE;
  huart->RxState = HAL_UART_STATE_BUSY_RX;
	
	serial_t *obj = get_serial_obj(huart);

  /* Enable the UART Error Interrupt: (Frame error, noise error, overrun error) */
  ATOMIC_SET_BIT(huart->Instance->IER, USART_INT_OE| USART_INT_PE | USART_INT_FE);

  huart->RxISR = UART_RxISR_8BIT;

  __HAL_UNLOCK(huart);

  /* Enable the UART Parity Error interrupt and Data Register Not Empty interrupt */
  ATOMIC_SET_BIT(huart->Instance->IER, USART_INT_RXDR);
  return HAL_OK;
}


HAL_StatusTypeDef HAL_UART_Receive_IT(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size)
{
  /* Check that a Rx process is not already ongoing */
  if (huart->RxState == HAL_UART_STATE_READY)
  {
    if ((pData == NULL) || (Size == 0U))
    {
      return HAL_ERROR;
    }

    __HAL_LOCK(huart);

    /* Set Reception type to Standard reception */
    //huart->ReceptionType = HAL_UART_RECEPTION_STANDARD;

    /* Check that USART RTOEN bit is set */
    //if (READ_BIT(huart->Instance->CR2, USART_CR2_RTOEN) != 0U)
    //{
      /* Enable the UART Receiver Timeout Interrupt */
      //ATOMIC_SET_BIT(huart->Instance->IMSC, UART_INTERRUPT_RX_TIMEOUT);
    //}

    return (UART_Start_Receive_IT(huart, pData, Size));
  }
  else
  {
    return HAL_BUSY;
  }
}


/**
  * @brief TX interrupt handler for 7 or 8 bits data word length .
  * @note   Function is called under interruption only, once
  *         interruptions have been enabled by HAL_UART_Transmit_IT().
  * @param huart UART handle.
  * @retval None
  */
static void UART_TxISR_8BIT(UART_HandleTypeDef *huart)
{
  serial_t *obj = get_serial_obj(huart);
  /* Check that a Tx process is ongoing */
  if (huart->gState == HAL_UART_STATE_BUSY_TX)
  {
    if (huart->TxXferCount == 0U)
    {
      /* Disable the UART Transmit Data Register Empty Interrupt */
      ATOMIC_CLEAR_BIT(huart->Instance->IER, USART_INT_TXDE);

	  /* Tx process is ended, restore huart->gState to Ready */
      huart->gState = HAL_UART_STATE_READY;

      /* Cleat TxISR function pointer */
      huart->TxISR = NULL;
	  
	        /*Call legacy weak Rx complete callback*/
	  if (obj) {
		obj->tx_callback(obj);
	  }
	  
    }
    else
    {
      huart->Instance->DR = (uint8_t)(*huart->pTxBuffPtr & (uint8_t)0xFF);
      huart->pTxBuffPtr++;
      huart->TxXferCount--;
    }
  }
}

/**
  * @brief Send an amount of data in interrupt mode.
  * @note   When UART parity is not enabled (PCE = 0), and Word Length is configured to 9 bits (M1-M0 = 01),
  *         the sent data is handled as a set of u16. In this case, Size must indicate the number
  *         of u16 provided through pData.
  * @note   When UART parity is not enabled (PCE = 0), and Word Length is configured to 9 bits (M1-M0 = 01),
  *         address of user data buffer containing data to be sent, should be aligned on a half word frontier (16 bits)
  *         (as sent data will be handled using u16 pointer cast). Depending on compilation chain,
  *         use of specific alignment compilation directives or pragmas might be required
  *         to ensure proper alignment for pData.
  * @param huart UART handle.
  * @param pData Pointer to data buffer (u8 or u16 data elements).
  * @param Size  Amount of data elements (u8 or u16) to be sent.
  * @retval HAL status
  */
HAL_StatusTypeDef HAL_UART_Transmit_IT(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size)
{
  /* Check that a Tx process is not already ongoing */
  if (huart->gState == HAL_UART_STATE_READY)
  {
    if ((pData == NULL) || (Size == 0U))
    {
      return HAL_ERROR;
    }

    __HAL_LOCK(huart);

    huart->pTxBuffPtr  = pData;
    huart->TxXferSize  = Size;
    huart->TxXferCount = Size;
    huart->TxISR       = NULL;

    huart->ErrorCode = HAL_UART_ERROR_NONE;
    huart->gState = HAL_UART_STATE_BUSY_TX;

    huart->TxISR = UART_TxISR_8BIT;

    __HAL_UNLOCK(huart);

    /* Enable the Transmit Data Register Empty interrupt */
    ATOMIC_SET_BIT(huart->Instance->IER, USART_INT_TXDE);
	
	
	if (huart->TxISR != NULL)
    {
      huart->TxISR(huart);
    }

    return HAL_OK;
  }
  else
  {
    return HAL_BUSY;
  }
}

/**
 * Begin asynchronous RX transfer (enable interrupt for data collecting)
 *
 * @param obj : pointer to serial_t structure
 * @param callback : function call at the end of reception
 * @retval none
 */
void uart_attach_rx_callback(serial_t *obj, void (*callback)(serial_t *))
{
  if (obj == NULL) {
    return;
  }

  /* Exit if a reception is already on-going */
  if (serial_rx_active(obj)) {
    return;
  }
  obj->rx_callback = callback;

  /* Must disable interrupt to prevent handle lock contention */
  NVIC_DisableIRQ(obj->irq);

  HAL_UART_Receive_IT(uart_handlers[obj->index], &(obj->recv), 1);

  /* Enable interrupt */
  NVIC_EnableIRQ(obj->irq);
}

void uart_attach_tx_callback(serial_t *obj, int (*callback)(serial_t *), size_t size)
{
  if (obj == NULL) {
    return;
  }
  obj->tx_callback = callback;

  /* Must disable interrupt to prevent handle lock contention */
  NVIC_DisableIRQ(obj->irq);

  /* The following function will enable UART_IT_TXE and error interrupts */
  HAL_UART_Transmit_IT(uart_handlers[obj->index], &obj->tx_buff[obj->tx_tail], size);

  /* Enable interrupt */
  NVIC_EnableIRQ(obj->irq);
}

uint8_t serial_rx_active(serial_t *obj)
{
  return ((HAL_UART_GetState(uart_handlers[obj->index]) & HAL_UART_STATE_BUSY_RX) == HAL_UART_STATE_BUSY_RX);
}

/**
 * Attempts to determine if the serial peripheral is already in use for TX
 *
 * @param obj The serial object
 * @return Non-zero if the TX transaction is ongoing, 0 otherwise
 */
uint8_t serial_tx_active(serial_t *obj)
{
  return ((HAL_UART_GetState(uart_handlers[obj->index]) & HAL_UART_STATE_BUSY_TX) == HAL_UART_STATE_BUSY_TX);
}

int uart_getc(serial_t *obj, unsigned char *c)
{
  if (obj == NULL) {
    return -1;
  }

  if (serial_rx_active(obj)) {
    return -1; /* Transaction ongoing */
  }

  *c = (unsigned char)(obj->recv);
  /* Restart RX irq */
  HAL_UART_Receive_IT(uart_handlers[obj->index], &(obj->recv), 1);

  return 0;
}

//void HAL_UART_IRQHandler(UART_HandleTypeDef *huart) __attribute__((section("foo")));

void HAL_UART_IRQHandler(UART_HandleTypeDef *huart)
{
  uint32_t isrflags   = READ_REG(huart->Instance->SR);

  uint32_t errorflags;
  uint32_t errorcode;
  
  serial_t *obj = get_serial_obj(huart);

  /* If no error occurs */
  errorflags = (isrflags & (uint32_t)(USART_FLAG_OE | USART_FLAG_PE | USART_FLAG_FE));
  if (errorflags == 0U)
  {
    /* UART in mode Receiver ---------------------------------------------------*/
   if(USART_GetFlagStatus(huart->Instance,USART_FLAG_RXDR))
    {
      if (huart->RxISR != NULL)
      {
        huart->RxISR(huart);
      }
			USART_ClearFlag(huart->Instance,USART_FLAG_RXDR);
      return;
    }
  }

  /* If some errors occur */
  if ((errorflags != 0))
  {
    /* UART parity error interrupt occurred -------------------------------------*/
    if (((isrflags & USART_FLAG_PE) != 0U))
    {
      //__HAL_UART_CLEAR_FLAG(huart, UART_CLEAR_PEF);
	  obj->pae++;
	  USART_ClearFlag(huart->Instance,USART_FLAG_PE);

      huart->ErrorCode |= HAL_UART_ERROR_PE;
    }

    /* UART frame error interrupt occurred --------------------------------------*/
    if (((isrflags & USART_FLAG_FE) != 0U) )
    {
		obj->fre++;
      //__HAL_UART_CLEAR_FLAG(huart, UART_CLEAR_FEF);
	  USART_ClearFlag(huart->Instance,USART_FLAG_FE);

      huart->ErrorCode |= HAL_UART_ERROR_FE;
    }

    /* UART Over-Run interrupt occurred -----------------------------------------*/
    if (((isrflags & USART_FLAG_OE) != 0U))
    {
      //__HAL_UART_CLEAR_FLAG(huart, UART_CLEAR_OREF);
	  obj->ove++;
	  USART_ClearFlag(huart->Instance,USART_FLAG_OE);

      huart->ErrorCode |= HAL_UART_ERROR_ORE;
    }

    /* Call UART Error Call back function if need be ----------------------------*/
    if (huart->ErrorCode != HAL_UART_ERROR_NONE)
    {
      /* UART in mode Receiver --------------------------------------------------*/
      if(USART_GetFlagStatus(huart->Instance,USART_FLAG_RXDR))
      {
        if (huart->RxISR != NULL)
        {
          huart->RxISR(huart);
        }
      }

      /* If Error is to be considered as blocking :
          - Receiver Timeout error in Reception
          - Overrun error in Reception
          - any error occurs in DMA mode reception
      */
      errorcode = huart->ErrorCode;

    }
		USART_ClearFlag(huart->Instance,USART_FLAG_RXDR);
		if (obj && !serial_rx_active(obj)) {
			HAL_UART_Receive_IT(huart, &(obj->recv), 1);
		}
    return;

  } /* End if some error occurs */
	
	  /* UART in mode Transmitter ------------------------------------------------*/
  if (USART_GetIntStatus(huart->Instance, USART_INT_TXDE) &&
      USART_GetFlagStatus(huart->Instance, USART_FLAG_TXDE))
  {
		USART_ClearFlag(huart->Instance,USART_INT_TXDE);
    if (uart_handlers[0]->TxISR != NULL)
    {
      uart_handlers[0]->TxISR(uart_handlers[0]);
    }
    return;
  }

}

HAL_UART_StateTypeDef HAL_UART_GetState(UART_HandleTypeDef *huart)
{
  uint32_t temp1;
  uint32_t temp2;
  temp1 = huart->gState;
  temp2 = huart->RxState;

  return (HAL_UART_StateTypeDef)(temp1 | temp2);
}

void USART0_IRQHandler(void)
{

  /* Clear pending interrupt */
  NVIC_ClearPendingIRQ(USART0_IRQn);
  HAL_UART_IRQHandler(uart_handlers[0]);  
}	

#if (LIBCFG_USART_LIN)
/*********************************************************************************************************//**
 * @brief USART/UART LIN Mode send break to Tx.
 * @param USARTx: where USARTx is the selected USART/UART from the USART/UART peripherals.
 * @retval None
 ************************************************************************************************************/
void USART_LIN_SendBreak(HT_USART_TypeDef* USARTx)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));

  USARTx->CR |= USART_LINSENDBREAK;
}


/*********************************************************************************************************//**
 * @brief Configure the break detection length in LIN mode.
 * @param USARTx: where USARTx is the selected USART/UART from the USART/UART peripherals.
 * @param length: data length in byte.
 *   This parameter can be one of the following values:
 *     @arg USART_LINLENGTH_11BIT
 *     @arg USART_LINLENGTH_10BIT
 * @retval None
 ************************************************************************************************************/
void USART_LIN_LengthSelect(HT_USART_TypeDef* USARTx, u32 USART_LIN_Length)
{
  /* Check the parameters                                                                                   */
  Assert_Param(IS_USART(USARTx));
  Assert_Param(IS_USART_LINLENGTH(USART_LIN_Length));

  if (USART_LIN_Length != USART_LINLENGTH_10BIT)
  {
    USARTx->CR |= USART_LINLENGTH_11BIT;
  }
  else
  {
    USARTx->CR &= USART_LINLENGTH_10BIT;
  }
}
#endif
/**
  * @}
  */


/**
  * @}
  */

/**
  * @}
  */
