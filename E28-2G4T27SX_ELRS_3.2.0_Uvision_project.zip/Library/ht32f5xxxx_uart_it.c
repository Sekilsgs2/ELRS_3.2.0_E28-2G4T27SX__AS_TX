//-------------------------------------------------------------------
// ht32f5xxxx_uart_it.c
//-------------------------------------------------------------------
#include "ht32.h"
#include "HT32IO.h"

//-------------------------------------------------------------------
void USART0_IRQHandler(void)
{
  // Rx, move data from UART to buffer
  if(USART_GetFlagStatus(HT_USART0,USART_FLAG_RXDR))
  {
		unsigned char ch=USART_ReceiveData(HT_USART0);
		uint16_t i = (unsigned int)(*_rx_buffer_head_u0 + 1) % SERIAL_RX_BUFFER_SIZE;
		if (i != *_rx_buffer_tail_u0)
		{
			_rx_buffer_u0[*_rx_buffer_head_u0] = ch;
			*_rx_buffer_head_u0 = i;
		}
    USART_ClearFlag(HT_USART0,USART_FLAG_RXDR);
		return;
  }
  /* Tx, move data from buffer to UART                                                                      */
  if (USART_GetIntStatus(HT_USART0, USART_INT_TXDE) &&
      USART_GetFlagStatus(HT_USART0, USART_FLAG_TXDE))
  {
		unsigned char c = _tx_buffer_u0[*_tx_buffer_tail_u0];
    USART_ClearFlag(HT_USART0,USART_INT_TXDE);
		USART_SendData(HT_USART0, c); 
		*_tx_buffer_tail_u0 = (*_tx_buffer_tail_u0 + 1) % SERIAL_TX_BUFFER_SIZE;
		if (*_tx_buffer_head_u0 == *_tx_buffer_tail_u0)
		{
			// Buffer empty, so disable interrupts
			*_tx_buffer_head_u0 = *_tx_buffer_tail_u0 = 0;
			USART_IntConfig(HT_USART0,USART_INT_TXDE,DISABLE);
		}
  }
}
