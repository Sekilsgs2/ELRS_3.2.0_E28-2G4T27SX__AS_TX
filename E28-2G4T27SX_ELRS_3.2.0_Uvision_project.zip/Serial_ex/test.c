#include "HT32IO.h"
#include "test.h"

void func1 (void)
{
	uint32_t test11 = 22;
}
