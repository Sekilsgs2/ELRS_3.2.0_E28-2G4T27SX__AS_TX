#include "HT32_hwTimer.h"

void (*hwTimer::callbackTick)() = nullptr;
void (*hwTimer::callbackTock)() = nullptr;

callback_function_t callbacks[4];

void hwTimer::attachInterrupt(callback_function_t callback)
{
    callbacks[0] = callback;
}

/**
  * @brief  Dettach interrupt callback on Capture/Compare event
  * @param  channel: Arduino channel [1..4]
  * @retval None
  */
void hwTimer::detachInterrupt()
{
  callbacks[0] = NULL;
}


volatile uint32_t hwTimer::HWtimerInterval = TimerIntervalUSDefault;
bool hwTimer::running = false;
bool hwTimer::alreadyInit = false;

volatile bool hwTimer::isTick = false;
volatile int32_t hwTimer::PhaseShift = 0;
volatile int32_t hwTimer::FreqOffset = 0;
uint32_t hwTimer::NextTimeout;

volatile int32_t bftik = 0;

#define HWTIMER_TICKS_PER_US 48
#define HWTIMER_PRESCALER (clockCyclesPerMicrosecond() / HWTIMER_TICKS_PER_US)

//#define OneShot_Delay(cnt)                        {HT_BFTM0->SR = 0;\
//                                                   HT_BFTM0->CMP = cnt;\
//                                                   HT_BFTM0->CR |= (1 << 2);\
//                                                   while (HT_BFTM0->SR == 0){};}


#define OneShot_Delay(cnt)                        {HT_BFTM0->CMP = cnt;}

#define OneShot_Delay1(cnt)                        {BFTM_ClearFlag(HT_BFTM0);\
                                                   BFTM_SetCompare(HT_BFTM0, cnt);\
                                                   BFTM_EnaCmd(HT_BFTM0, ENABLE);\
                                                   while (BFTM_GetFlagStatus(HT_BFTM0) != SET){};}


void hwTimer::init()
{
	{ /* Enable peripheral clock                                                                              */
		CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
		CKCUClock.Bit.BFTM0 = 1;
		CKCU_PeripClockConfig(CKCUClock, ENABLE);
	}

	/* BFTM as one shot mode                                                                                  */
	BFTM_SetCounter(HT_BFTM0, 0);
	//BFTM_OneShotModeCmd(HT_BFTM0, ENABLE);
	
	NVIC_SetPriority(BFTM0_IRQn, 0x4);
	BFTM_IntConfig(HT_BFTM0, ENABLE);
	running = false;
	alreadyInit = true;
}

void hwTimer::stop()
{
    //if (running)
    {	
		BFTM_EnaCmd(HT_BFTM0, DISABLE);
		BFTM_SetCounter(HT_BFTM0, 0);
        hwTimer::detachInterrupt();
		NVIC_DisableIRQ(BFTM0_IRQn);
        running = false;
    }
}

void ICACHE_RAM_ATTR hwTimer::resume()
{
    //if (running == false)
    {
        noInterrupts();
        hwTimer::attachInterrupt(hwTimer::callback);
#if defined(TARGET_TX)
			OneShot_Delay(HWtimerInterval);

#else
        // The STM32 timer fires tock() ASAP after enabling, so mimic that behavior
        // tock() should always be the first event to maintain consistency
        isTick = false;
        // When using EDGE triggered timer, enabling the timer causes an edge so the interrupt
        // is fired immediately, so this emulates the STM32 behaviour
       	NextTimeout = (2 * HWTIMER_TICKS_PER_US * HWTIMER_PRESCALER);
			  OneShot_Delay(NextTimeout);
#endif
				BFTM_EnaCmd(HT_BFTM0, ENABLE);
			  NVIC_EnableIRQ(BFTM0_IRQn);
        interrupts();		
        running = true;
    }
}

void hwTimer::updateInterval(uint32_t newTimerInterval)
{
    // timer should not be running when updateInterval() is called
    hwTimer::HWtimerInterval = newTimerInterval * (HWTIMER_TICKS_PER_US);
	
#if defined(TARGET_TX)
		if (!alreadyInit)
			init();
    OneShot_Delay(HWtimerInterval);
#endif
}

void ICACHE_RAM_ATTR hwTimer::resetFreqOffset()
{
    FreqOffset = 0;
}

void ICACHE_RAM_ATTR hwTimer::incFreqOffset()
{
    FreqOffset++;
}

void ICACHE_RAM_ATTR hwTimer::decFreqOffset()
{
    FreqOffset--;
}

void ICACHE_RAM_ATTR hwTimer::phaseShift(int32_t newPhaseShift)
{
    int32_t minVal = -(hwTimer::HWtimerInterval >> 2);
    int32_t maxVal = (hwTimer::HWtimerInterval >> 2);

    // phase shift is in microseconds
    hwTimer::PhaseShift = constrain(newPhaseShift, minVal, maxVal) * (HWTIMER_TICKS_PER_US * HWTIMER_PRESCALER);
}

void hwTimer::callback()
{
    if (!running)
    {
        //return;
    }
		#if defined(TARGET_TX)
        callbackTock();
		#else
    NextTimeout = (hwTimer::HWtimerInterval >> 1) + (FreqOffset * HWTIMER_PRESCALER);
    if (hwTimer::isTick)
    {
        OneShot_Delay(NextTimeout);
        if (callbackTick) callbackTick();
    }
    else
    {
        NextTimeout += hwTimer::PhaseShift;
        OneShot_Delay(NextTimeout);
        hwTimer::PhaseShift = 0;
        if (callbackTock) callbackTock();
    }
    hwTimer::isTick = !hwTimer::isTick;
		#endif
}

extern "C" {

void BFTM0_IRQHandler(void)
{
  BFTM_ClearFlag(HT_BFTM0);
	if (callbacks[0])
		callbacks[0]();
}
}
