#pragma once

#include "device.h"

extern device_t VTxSPI_device;

extern uint8_t vtxSPIBandChannelIdx;
extern uint8_t vtxSPIPowerIdx;
extern uint8_t vtxSPIPitmode;

void VTxOutputMinimum();
