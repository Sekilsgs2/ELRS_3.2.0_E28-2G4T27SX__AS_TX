#ifdef __cplusplus
 extern "C" {
#endif
void func1(void);
	
#ifdef __cplusplus
}
#endif	 