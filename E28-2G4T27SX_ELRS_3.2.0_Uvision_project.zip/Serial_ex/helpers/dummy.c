int __helpers_dummy;
