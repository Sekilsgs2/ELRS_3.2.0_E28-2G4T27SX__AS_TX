#include "elrs_eeprom.h"
#include "targets.h"
#include "logging.h"

void
ELRS_EEPROM::Begin()
{
        eeprom_buffer_fill();
}

uint8_t
ELRS_EEPROM::ReadByte(const uint32_t address)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        // address is out of bounds
        ERRLN("EEPROM address is out of bounds");
        return 0;
    }
    return eeprom_buffered_read_byte(address);
}

void
ELRS_EEPROM::WriteByte(const uint32_t address, const uint8_t value)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        // address is out of bounds
        ERRLN("EEPROM address is out of bounds");
        return;
    }
    eeprom_buffered_write_byte(address, value);
}

void
ELRS_EEPROM::Commit()
{
	int ret = 0;
	DBGLN("Start commit");
	
	ret = eeprom_buffer_flush();
    if (ret != 0) {
		DBGLN("EEPROM commit failed %d", ret);
	}
	
    else
		DBGLN("EEPROM commit success %d", ret);
}

