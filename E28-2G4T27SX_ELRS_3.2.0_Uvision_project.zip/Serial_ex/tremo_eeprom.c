/**
  ******************************************************************************
  * @file    stm32_eeprom.c
  * @brief   Provides emulated eeprom from flash
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2016-2021, STMicroelectronics
  * All rights reserved.
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

#include "HT32IO.h"
//#include "tremo_eeprom.h"

#ifdef __cplusplus
extern "C" {
#endif

#define E2END 1024
u32 err;

void FLASH_Erase(void)
{
  u32 Addr;
  FLASH_State FLASHState;
  for (Addr = _EEPROM_BASE; Addr < _EEPROM_END; Addr += FLASH_PAGE_SIZE)
  {
    FLASHState = FLASH_ErasePage(Addr);
    if (FLASHState != FLASH_COMPLETE)
    {
      err++;
    }
  }
}

static uint8_t eeprom_buffer[E2END + 1] __attribute__((aligned(8))) = {0};

/**
  * @brief  Function reads a byte from emulated eeprom (flash)
  * @param  pos : address to read
  * @retval byte : data read from eeprom
  */
uint8_t eeprom_read_byte(const uint32_t pos)
{
  eeprom_buffer_fill();
  return eeprom_buffered_read_byte(pos);
}

/**
  * @brief  Function writes a byte to emulated eeprom (flash)
  * @param  pos : address to write
  * @param  value : value to write
  * @retval none
  */
void eeprom_write_byte(uint32_t pos, uint8_t value)
{
  eeprom_buffered_write_byte(pos, value);
  eeprom_buffer_flush();
}


/**
  * @brief  Function reads a byte from the eeprom buffer
  * @param  pos : address to read
  * @retval byte : data read from eeprom
  */
uint8_t eeprom_buffered_read_byte(const uint32_t pos)
{
  return eeprom_buffer[pos];
}

/**
  * @brief  Function writes a byte to the eeprom buffer
  * @param  pos : address to write
  * @param  value : value to write
  * @retval none
  */
void eeprom_buffered_write_byte(uint32_t pos, uint8_t value)
{
  eeprom_buffer[pos] = value;
}

/**
  * @brief  This function copies the data from flash into the buffer
  * @param  none
  * @retval none
  */
void eeprom_buffer_fill(void)
{
  memcpy(eeprom_buffer, (uint8_t *)(_EEPROM_BASE), E2END + 1);
}

/**
  * @brief  This function writes the buffer content into the flash
  * @param  none
  * @retval none
  */
int eeprom_buffer_flush(void)
{
  uint32_t data = 0;
  uint32_t offset = 0;
  uint32_t address = _EEPROM_BASE;
  uint32_t address_end = _EEPROM_END;

	FLASH_Erase();
  FLASH_State FLASHState;
	
  while (address <= address_end)
  {
			memcpy(&data, eeprom_buffer + offset, sizeof(uint32_t));
			FLASHState = FLASH_ProgramWordData(address, data);
			if (FLASHState != FLASH_COMPLETE)
			{
				address = address_end + 1;
			}
			else
			{
				address += 4;
        offset += 4;
			}
  }
	
	return 0;
}

#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
