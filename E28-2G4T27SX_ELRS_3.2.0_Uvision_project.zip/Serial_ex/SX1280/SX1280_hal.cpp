/*
  ______                              _
 / _____)             _              | |
( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
(______/|_____)_|_|_| \__)_____)\____)_| |_|
    (C)2016 Semtech

Description: Handling of the node configuration protocol

License: Revised BSD License, see LICENSE.TXT file include in the project

Maintainer: Miguel Luis, Gregory Cristian and Matthieu Verdy

Modified and adapted by Alessandro Carcione for ELRS project
*/

#ifndef UNIT_TEST
#include "SX1280_Regs.h"
#include "SX1280_hal.h"
#include "logging.h"
#include "ht32.h"

volatile uint32_t wait_t = 0;

u16 SX1280_SendByte(u8 byte)
{
  /* Loop while Tx buffer register is empty                                                                 */
  while (!SPI_GetFlagStatus(SX1280_SPI, SPI_FLAG_TXBE));

  /* Send byte through the SPIx peripheral                                                                  */
  SPI_SendData(SX1280_SPI, byte);

  /* Loop while Rx is not empty                                                                             */
  while (!SPI_GetFlagStatus(SX1280_SPI, SPI_FLAG_RXBNE));

  /* Return the byte read from the SPI                                                                      */
  return SPI_ReceiveData(SX1280_SPI);
}

u16 spi_transfer(uint8_t *tx_buffer, uint8_t *rx_buffer,
                          uint16_t len)
{
  u16 ret = len;
  uint32_t size = len;

  while (size--) {
    while (!SPI_GetFlagStatus(SX1280_SPI, SPI_FLAG_TXBE));
    SPI_SendData(SX1280_SPI, *tx_buffer++);

    while (!SPI_GetFlagStatus(SX1280_SPI, SPI_FLAG_RXBNE));
    *rx_buffer++ = SPI_ReceiveData(SX1280_SPI);
  }

  return ret;
}

void transfer(void *_buf, size_t _count)
{
  if ((_count == 0) || (_buf == NULL)) {
    return;
  }

  digitalWrite(PA3, LOW);

  spi_transfer(((uint8_t *)_buf), ((uint8_t *)_buf), _count);

  digitalWrite(PA3, HIGH);
}

u32 SPI_SX1280_Init(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  SPI_InitTypeDef  SPI_InitStructure;

  /*  Enable AFIO & SPI SEL pin port & SPI clock                                                            */
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  SX1280_SPI_SEL_CLK(CKCUClock) = 1;
  SX1280_SPI_CLK(CKCUClock)     = 1;
  CKCUClock.Bit.AFIO           = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  /*  Configure SPI SEL pin
                                                                                 */
	HT32F_DVB_GPxConfig(SX1280_SPI_SEL_GPIO_ID, SX1280_SPI_SEL_GPIO_PIN, SX1280_SPI_SEL_AFIO_MODE);
  GPIO_SetOutBits(GPIO_PORT[SX1280_SPI_SEL_GPIO_ID], SX1280_SPI_SEL_GPIO_PIN);
  GPIO_DirectionConfig(GPIO_PORT[SX1280_SPI_SEL_GPIO_ID], SX1280_SPI_SEL_GPIO_PIN, GPIO_DIR_OUT);
	
	GPIO_PullResistorConfig(HT_GPIOA, SX1280_SPI_SEL_GPIO_PIN, GPIO_PR_UP);

  /*  Configure SPI SCK pin, SPI MISO pin, SPI MOSI pin                                                     */
	HT32F_DVB_GPxConfig(SX1280_SPI_SEL_GPIO_ID, SX1280_SPI_SEL_GPIO_PIN, SX1280_SPI_SEL_AFIO_MODE);
  HT32F_DVB_GPxConfig(SX1280_SPI_SCK_GPIO_ID, SX1280_SPI_SCK_AFIO_PIN, SX1280_SPI_SCK_AFIO_MODE);
  HT32F_DVB_GPxConfig(SX1280_SPI_MISO_GPIO_ID, SX1280_SPI_MISO_AFIO_PIN, SX1280_SPI_MISO_AFIO_MODE);
  HT32F_DVB_GPxConfig(SX1280_SPI_MOSI_GPIO_ID, SX1280_SPI_MOSI_AFIO_PIN, SX1280_SPI_MOSI_AFIO_MODE);

  /*  SPI Configuration                                                                                     */
  SPI_InitStructure.SPI_Mode = SPI_MASTER;
  SPI_InitStructure.SPI_FIFO = SPI_FIFO_DISABLE;
  SPI_InitStructure.SPI_DataLength = SPI_DATALENGTH_8;
  SPI_InitStructure.SPI_SELMode = SPI_SEL_SOFTWARE;
  SPI_InitStructure.SPI_SELPolarity = SPI_SELPOLARITY_LOW;
  SPI_InitStructure.SPI_FirstBit = SPI_FIRSTBIT_MSB;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_LOW;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_FIRST;
  SPI_InitStructure.SPI_RxFIFOTriggerLevel = 0;
  SPI_InitStructure.SPI_TxFIFOTriggerLevel = 0;
  #if (LIBCFG_MAX_SPEED > 48000000)
  SPI_InitStructure.SPI_ClockPrescaler = 4;
  #else
  SPI_InitStructure.SPI_ClockPrescaler = 4;
  #endif
  SPI_Init(SX1280_SPI, &SPI_InitStructure);

  SPI_SELOutputCmd(SX1280_SPI, ENABLE);

  SPI_Cmd(SX1280_SPI, ENABLE);

  return TRUE;
}

SX1280Hal *SX1280Hal::instance = NULL;

SX1280Hal::SX1280Hal()
{
    instance = this;
}

void SX1280Hal::end()
{
    TXRXdisable(); // make sure the RX/TX amp pins are disabled
    //detachInterrupt(GPIO_PIN_DIO1);

    IsrCallback_1 = nullptr; // remove callbacks
    IsrCallback_2 = nullptr; // remove callbacks
}

void SX1280Hal::init()
{
    //DBGLN("Hal Init");

    rx_enabled = false;
    tx1_enabled = false;
    tx2_enabled = false;
	
  { /* Enable peripheral clock                                                                              */
    CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
    CKCUClock.Bit.AFIO = 1;
	  CKCUClock.Bit.EXTI = 1;
		CKCUClock.Bit.HTPA = 1;
    CKCUClock.Bit.HTPB = 1;
		CKCUClock.Bit.HTPC = 1;
		
    CKCU_PeripClockConfig(CKCUClock, ENABLE);
  }

	//SX1280
	{
		HT32F_DVB_GPxConfig(SX1280_BUSY_GPIO_ID, SX1280_BUSY_GPIO_PIN, SX1280_BUSY_AFIO_MODE);
		//GPIO_PullResistorConfig(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN, GPIO_PR_DOWN);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN, GPIO_DIR_IN);
		GPIO_InputConfig(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN, ENABLE);
		
		HT32F_DVB_GPxConfig(SX1280_DIO1_GPIO_ID, SX1280_DIO1_GPIO_PIN, SX1280_DIO1_AFIO_MODE);
		//GPIO_PullResistorConfig(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN, GPIO_PR_DOWN);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_DIO1_GPIO_ID], SX1280_DIO1_GPIO_PIN, GPIO_DIR_IN);
		GPIO_InputConfig(GPIO_PORT[SX1280_DIO1_GPIO_ID], SX1280_DIO1_GPIO_PIN, ENABLE);

		HT32F_DVB_GPxConfig(SX1280_DIO2_GPIO_ID, SX1280_DIO2_GPIO_PIN, SX1280_DIO1_AFIO_MODE);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_DIO2_GPIO_ID], SX1280_DIO2_GPIO_PIN, GPIO_DIR_IN);
		GPIO_InputConfig(GPIO_PORT[SX1280_DIO2_GPIO_ID], SX1280_DIO2_GPIO_PIN, ENABLE);

		HT32F_DVB_GPxConfig(SX1280_DIO3_GPIO_ID, SX1280_DIO3_GPIO_PIN, SX1280_DIO1_AFIO_MODE);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_DIO3_GPIO_ID], SX1280_DIO3_GPIO_PIN, GPIO_DIR_IN);
		GPIO_InputConfig(GPIO_PORT[SX1280_DIO3_GPIO_ID], SX1280_DIO3_GPIO_PIN, ENABLE);
		
		
		HT32F_DVB_GPxConfig(SX1280_RESET_GPIO_ID, SX1280_RESET_GPIO_PIN, SX1280_RESET_AFIO_MODE);
		GPIO_PullResistorConfig(GPIO_PORT[SX1280_RESET_GPIO_ID], SX1280_RESET_GPIO_PIN, GPIO_PR_UP);
		GPIO_WriteOutBits(GPIO_PORT[SX1280_RESET_GPIO_ID], SX1280_RESET_GPIO_PIN, SET);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_RESET_GPIO_ID], SX1280_RESET_GPIO_PIN, GPIO_DIR_OUT);	
		
		HT32F_DVB_GPxConfig(SX1280_SKYPOWER_GPIO_ID, SX1280_SKYPOWER_GPIO_PIN, SX1280_SKYPOWER_AFIO_MODE);
		GPIO_WriteOutBits(GPIO_PORT[SX1280_SKYPOWER_GPIO_ID], SX1280_SKYPOWER_GPIO_PIN, SET);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_SKYPOWER_GPIO_ID], SX1280_SKYPOWER_GPIO_PIN, GPIO_DIR_OUT);	

		HT32F_DVB_GPxConfig(SX1280_TX_EN_GPIO_ID, SX1280_TX_EN_GPIO_PIN, SX1280_TX_EN_AFIO_MODE);
		GPIO_WriteOutBits(GPIO_PORT[SX1280_TX_EN_GPIO_ID], SX1280_TX_EN_GPIO_PIN, RESET);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_TX_EN_GPIO_ID], SX1280_TX_EN_GPIO_PIN, GPIO_DIR_OUT);	
		
		HT32F_DVB_GPxConfig(SX1280_RX_EN_GPIO_ID, SX1280_RX_EN_GPIO_PIN, SX1280_RX_EN_AFIO_MODE);
		GPIO_WriteOutBits(GPIO_PORT[SX1280_RX_EN_GPIO_ID], SX1280_RX_EN_GPIO_PIN, RESET);
		GPIO_DirectionConfig(GPIO_PORT[SX1280_RX_EN_GPIO_ID], SX1280_RX_EN_GPIO_PIN, GPIO_DIR_OUT);	
		
		
	}
    //digitalWrite(PA15, HIGH);

    if (GPIO_PIN_TX_ENABLE != UNDEF_PIN)
    {
        //pinMode(GPIO_PIN_TX_ENABLE, OUTPUT);
        //digitalWrite(GPIO_PIN_TX_ENABLE, LOW);
    }

    if (GPIO_PIN_RX_ENABLE != UNDEF_PIN)
    {
        //pinMode(GPIO_PIN_RX_ENABLE, OUTPUT);
        //digitalWrite(GPIO_PIN_RX_ENABLE, LOW);
    }

		SPI_SX1280_Init();

    //attachInterrupt(digitalPinToInterrupt(PC6), this->busyISR, CHANGE); //not used atm
    attachInterrupt(PC6, this->dioISR_1, IT_RISING);
}

//void ICACHE_RAM_ATTR SX1280Hal::setNss(uint8_t radioNumber, bool state)
//{
	//if (state) 
		//digitalWrite(PA3, HIGH);
	//else
		//digitalWrite(PA3, LOW);
//}

#define setNss(val,test)

void SX1280Hal::reset(void)
{
	GPIO_WriteOutBits(GPIO_PORT[SX1280_RESET_GPIO_ID], SX1280_RESET_GPIO_PIN, RESET);
	delay(50);
	GPIO_WriteOutBits(GPIO_PORT[SX1280_RESET_GPIO_ID], SX1280_RESET_GPIO_PIN, SET);
	delay(50);
	while (GPIO_ReadInBit(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN) == SET)
	{
	}
}

void ICACHE_RAM_ATTR SX1280Hal::WriteCommand(SX1280_RadioCommands_t command, uint8_t val, SX12XX_Radio_Number_t radioNumber, uint32_t busyDelay)
{
    WriteCommand(command, &val, 1, radioNumber, busyDelay);
}

void ICACHE_RAM_ATTR SX1280Hal::WriteCommand(SX1280_RadioCommands_t command, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber, uint32_t busyDelay)
{
    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 1];

    OutBuffer[0] = (uint8_t)command;
    memcpy(OutBuffer + 1, buffer, size);

    WaitOnBusy(radioNumber);
    setNss(radioNumber, LOW);
    transfer(OutBuffer, (uint8_t)sizeof(OutBuffer));
    setNss(radioNumber, HIGH);

    BusyDelay(busyDelay);
}

void ICACHE_RAM_ATTR SX1280Hal::ReadCommand(SX1280_RadioCommands_t command, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber)
{
    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 2];
    #define RADIO_GET_STATUS_BUF_SIZEOF 3 // special case for command == SX1280_RADIO_GET_STATUS, fixed 3 bytes packet size

    WaitOnBusy(radioNumber);
    setNss(radioNumber, LOW);

    if (command == SX1280_RADIO_GET_STATUS)
    {
        OutBuffer[0] = (uint8_t)command;
        OutBuffer[1] = 0x00;
        OutBuffer[2] = 0x00;
        transfer(OutBuffer, RADIO_GET_STATUS_BUF_SIZEOF);
        buffer[0] = OutBuffer[0];
    }
    else
    {
        OutBuffer[0] = (uint8_t)command;
        OutBuffer[1] = 0x00;
        memcpy(OutBuffer + 2, buffer, size);
        transfer(OutBuffer, sizeof(OutBuffer));
        memcpy(buffer, OutBuffer + 2, size);
    }
    setNss(radioNumber, HIGH);
}

void ICACHE_RAM_ATTR SX1280Hal::WriteRegister(uint16_t address, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber)
{
    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 3];

    OutBuffer[0] = (SX1280_RADIO_WRITE_REGISTER);
    OutBuffer[1] = ((address & 0xFF00) >> 8);
    OutBuffer[2] = (address & 0x00FF);

    memcpy(OutBuffer + 3, buffer, size);

    WaitOnBusy(radioNumber);
    setNss(radioNumber, LOW);
    transfer(OutBuffer, (uint8_t)sizeof(OutBuffer));
    setNss(radioNumber, HIGH);

    BusyDelay(15);
}

void ICACHE_RAM_ATTR SX1280Hal::WriteRegister(uint16_t address, uint8_t value, SX12XX_Radio_Number_t radioNumber)
{
    WriteRegister(address, &value, 1, radioNumber);
}

void ICACHE_RAM_ATTR SX1280Hal::ReadRegister(uint16_t address, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber)
{
    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 4];

    OutBuffer[0] = (SX1280_RADIO_READ_REGISTER);
    OutBuffer[1] = ((address & 0xFF00) >> 8);
    OutBuffer[2] = (address & 0x00FF);
    OutBuffer[3] = 0x00;

    WaitOnBusy(radioNumber);
    setNss(radioNumber, LOW);

    transfer(OutBuffer, uint8_t(sizeof(OutBuffer)));
    memcpy(buffer, OutBuffer + 4, size);

    setNss(radioNumber, HIGH);
}

uint8_t ICACHE_RAM_ATTR SX1280Hal::ReadRegister(uint16_t address, SX12XX_Radio_Number_t radioNumber)
{
    uint8_t data;
    ReadRegister(address, &data, 1, radioNumber);
    return data;
}

void ICACHE_RAM_ATTR SX1280Hal::WriteBuffer(uint8_t offset, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber)
{
    uint8_t localbuf[size];

    for (int i = 0; i < size; i++) // todo check if this is the right want to handle volatiles
    {
        localbuf[i] = buffer[i];
    }

    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 2];

    OutBuffer[0] = SX1280_RADIO_WRITE_BUFFER;
    OutBuffer[1] = offset;

    memcpy(OutBuffer + 2, localbuf, size);

    WaitOnBusy(radioNumber);

    setNss(radioNumber, LOW);
    transfer(OutBuffer, (uint8_t)sizeof(OutBuffer));
    setNss(radioNumber, HIGH);

    BusyDelay(15);
}

void ICACHE_RAM_ATTR SX1280Hal::ReadBuffer(uint8_t offset, uint8_t *buffer, uint8_t size, SX12XX_Radio_Number_t radioNumber)
{
    WORD_ALIGNED_ATTR uint8_t OutBuffer[size + 3];
    uint8_t localbuf[size];

    OutBuffer[0] = SX1280_RADIO_READ_BUFFER;
    OutBuffer[1] = offset;
    OutBuffer[2] = 0x00;

    WaitOnBusy(radioNumber);

    setNss(radioNumber, LOW);
    transfer(OutBuffer, uint8_t(sizeof(OutBuffer)));
    setNss(radioNumber, HIGH);

    memcpy(localbuf, OutBuffer + 3, size);

    for (int i = 0; i < size; i++) // todo check if this is the right wany to handle volatiles
    {
        buffer[i] = localbuf[i];
    }
}

bool ICACHE_RAM_ATTR SX1280Hal::WaitOnBusy(SX12XX_Radio_Number_t radioNumber)
{
        constexpr uint32_t wtimeoutUS = 1000U;
        uint32_t startTime = 0;

        while (true)
        {
            if (GPIO_ReadInBit(GPIO_PORT[SX1280_BUSY_GPIO_ID], SX1280_BUSY_GPIO_PIN) == RESET) return true;
            // Use this time to call micros().
            uint32_t now = micros();
            if (startTime == 0) startTime = now;
            if ((now - startTime) > wtimeoutUS) 
						{
							wait_t = micros();
							return false;
						}
        }
    return true;
}

void ICACHE_RAM_ATTR SX1280Hal::dioISR_1()
{
    if (instance->IsrCallback_1)
        instance->IsrCallback_1();
}

void ICACHE_RAM_ATTR SX1280Hal::dioISR_2()
{
    if (instance->IsrCallback_2)
        instance->IsrCallback_2();
}

void ICACHE_RAM_ATTR SX1280Hal::TXenable(SX12XX_Radio_Number_t radioNumber)
{
#if defined(PLATFORM_ESP32)

#else
    if (!tx1_enabled && !tx2_enabled && !rx_enabled)
    {
        digitalWrite(PB2, HIGH); //TX_EN
    }
    if (rx_enabled)
    {
        digitalWrite(PB4, LOW); //RX_DIS
        rx_enabled = false;
    }
    if (radioNumber == SX12XX_Radio_1 && !tx1_enabled)
    {
        digitalWrite(PB2, HIGH);
        tx1_enabled = true;
        tx2_enabled = false;
    }
    if (radioNumber == SX12XX_Radio_2 && !tx2_enabled)
    {
        digitalWrite(PB2, LOW);
        tx1_enabled = false;
        tx2_enabled = true;
    }
#endif
}

void ICACHE_RAM_ATTR SX1280Hal::RXenable()
{
#if defined(PLATFORM_ESP32)

#else
    if (!rx_enabled)
    {
        if (!tx1_enabled && !tx2_enabled)
            digitalWrite(PB4, HIGH);

        if (tx1_enabled)
        {
            digitalWrite(PB4, LOW);
            tx1_enabled = false;
        }

        digitalWrite(PB4, HIGH);
        rx_enabled = true;
    }
#endif
}

void ICACHE_RAM_ATTR SX1280Hal::TXRXdisable()
{
#if defined(PLATFORM_ESP32)
#else
    if (rx_enabled)
    {
        digitalWrite(PB4, LOW);
        rx_enabled = false;
    }
    if (tx1_enabled)
    {
        digitalWrite(PB2, LOW);
        tx1_enabled = false;
    }
    if (tx2_enabled)
    {
        digitalWrite(PB2, LOW);
        tx2_enabled = false;
    }
#endif
}

#endif // UNIT_TEST
